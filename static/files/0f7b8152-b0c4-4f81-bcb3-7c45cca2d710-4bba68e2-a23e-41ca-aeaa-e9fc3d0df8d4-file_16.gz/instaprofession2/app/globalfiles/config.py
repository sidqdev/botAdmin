import configparser


config = configparser.RawConfigParser()
config.read('config.ini')

mongo_config = dict(config['MONGO'])
bot_config = dict(config['BOT'])

mongo_config['port'] = int(mongo_config.get('port'))

