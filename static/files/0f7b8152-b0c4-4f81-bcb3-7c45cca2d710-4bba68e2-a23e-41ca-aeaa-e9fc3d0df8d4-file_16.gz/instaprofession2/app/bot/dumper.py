from .routes import dp
from . import scheduler


def dump_project(loop):
    loop.create_task(dp.start_polling())
