from aiogram.dispatcher.filters.state import State, StatesGroup
from app.globalfiles.database import get_level_ids


class Test(StatesGroup):
    test = State()
    menu = State()


class Spam(StatesGroup):
    get_text = State()
    approve = State()
