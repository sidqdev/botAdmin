from . import buttons
from app.globalfiles import database
from aiogram.types import CallbackQuery, Message
from typing import Union
from app.bot.loader import bot, dp, scheduler
from datetime import datetime, timedelta
from random import randint


async def send_message(message: Union[Message, CallbackQuery, int], menu_name) -> Message:
    items = await database.get_text(menu_name)
    text = str()
    image = str()
    button = list()

    for item in items:
        if item.get('text_id').endswith('label'):
            text = item.get('text')
            image = item.get('image')
        elif item.get('text_id').endswith('button'):
            button.append({'text': item.get('text'), 'data': item.get('image') or item.get('text_id')})

    reply_markup = buttons.InlineKeyboard(*button)

    if type(message) is Message:
        if image:
            return await message.answer_photo(caption=text, reply_markup=reply_markup,
                                       photo=image)
        else:
            return await message.answer(text=text, reply_markup=reply_markup)
    elif type(message) is int:
        if image:
            return await bot.send_photo(chat_id=message, caption=text, reply_markup=reply_markup,
                                 photo=image)
        else:
            return await bot.send_message(chat_id=message, text=text, reply_markup=reply_markup)
    elif type(message) is CallbackQuery:
        if image:
            return await message.message.answer_photo(caption=text, reply_markup=reply_markup,
                                       photo=image)
        else:
            return await message.message.answer(text=text, reply_markup=reply_markup)


async def get_main_menu(uid, state):
    prof = await state.get_data()
    print(prof)
    prof = prof.get('profession')
    items = await database.get_main_menu(prof)
    print(items)
    text = str()
    image = str()
    button = list()

    for item in items:
        if item.get('type') == 'label':
            text = item.get('text')
            image = item.get('link')
        elif item.get('type') == 'button':

            if datetime.now().date() >= item.get('date'):
                button.append({'text': item.get('text') + '✅', 'data': item.get('link')})
            else:
                button.append({'text': item.get('text') + '🔒', 'data': 'close'})

    reply_markup = buttons.InlineKeyboard(*button)

    if image:
        await bot.send_photo(uid, photo=image, caption=text, reply_markup=reply_markup)
    else:
        await bot.send_message(uid, text=text, reply_markup=reply_markup)


def send_time_out_menu(uid, menu_name, time_out):
    scheduler.add_job(send_message, 'date', [uid, menu_name],
                      run_date=datetime.now() + timedelta(seconds=time_out + randint(0, 200)))


async def push(uid, menu_name):
    print('push')
    msg = await send_message(uid, menu_name)
    async with dp.current_state(user=uid, chat=uid).proxy() as data:
        data['message_to_remove'] = data.get('message_to_remove', []) + [msg.message_id]


async def add_push(uid, menu_name, time_out):
    print(1)
    job = scheduler.add_job(push, 'date', [uid, menu_name],
                            run_date=datetime.now() + timedelta(seconds=time_out + randint(0, 200)))
    print(2)
    return job.id



