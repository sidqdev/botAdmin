import asyncio
from app.bot.dumper import dump_project


loop = asyncio.get_event_loop()
dump_project(loop)
loop.run_forever()
