from django.db import models
from django.contrib.postgres.fields import ArrayField


class ProfTest(models.Model):
    level_id = models.CharField(max_length=255, verbose_name='ID уровня', primary_key=True, unique=True)
    text = models.TextField(verbose_name='Сообщение')
    count_of_answers = models.IntegerField(verbose_name='Количевство ответов')
    type = models.CharField(verbose_name='Тип теста', max_length=255, choices=(('multi', 'Мульти'),
                                                                               ('mono', 'Моно')), default='multi')


class Professions(models.Model):
    id = models.CharField(max_length=255, primary_key=True)
    label = models.CharField(verbose_name='Название направления', max_length=255)
    text = models.TextField(verbose_name='Сообщение', default='')
    image = models.CharField(verbose_name='Картинка', max_length=255, default='')

    def __str__(self):
        return f'{self.label}-{self.id}'


class AnswersOnProfTest(models.Model):
    answer_id = models.IntegerField(verbose_name='Номер вопроса', default=0)
    profession = models.ForeignKey(verbose_name='Направление', to=Professions, on_delete=models.SET_NULL, null=True)
    test = models.ForeignKey(verbose_name='Тест', to=ProfTest, on_delete=models.SET_NULL, null=True)
    points = models.IntegerField(verbose_name='Кол-во баллов', default=1)


class BotTexts(models.Model):
    text_id = models.CharField(verbose_name='Айди текста', max_length=255, primary_key=True, unique=True)
    text = models.TextField(verbose_name='Текст')
    image = models.CharField(verbose_name='Картинка', max_length=255, blank=True)
    description = models.TextField(verbose_name='Описание', blank=True)


class BotUsers(models.Model):
    id = models.BigIntegerField(verbose_name='Айди', primary_key=True, unique=True)
    name = models.CharField(verbose_name='Имя', max_length=255)
    insert_time = models.DateTimeField(verbose_name='Время вхождения')


class Lessons(models.Model):
    id = models.AutoField(primary_key=True, unique=True)
    date = models.DateField(verbose_name='Дата')
    text = models.TextField(verbose_name='Сообщение')
    button_name = models.CharField(verbose_name='Сообщение в кнопке', max_length=255, default='')
    link = models.CharField(verbose_name='Ссылка на урок', max_length=255, default='')
    image = models.CharField(verbose_name='Картинка', max_length=255)
    profession = models.ForeignKey(verbose_name='Направление', to=Professions, on_delete=models.SET_NULL, null=True)

