from django.contrib import admin
from .models import *


class AnswersOnProfTestInline(admin.TabularInline):
    model = AnswersOnProfTest
    extra = 0
    can_delete = True
    show_change_link = False


class ProfTestView(admin.ModelAdmin):
    inlines = (AnswersOnProfTestInline, )
    list_display = ('level_id', 'text', 'type', 'count_of_answers')


class BotTextsView(admin.ModelAdmin):
    list_display = ('text_id', 'text', 'description')


class BotUsersView(admin.ModelAdmin):
    list_display = ('id', 'name', 'insert_time')


class LessonsView(admin.ModelAdmin):
    list_display = ('date', 'text', 'button_name', 'profession')


admin.site.register(ProfTest, ProfTestView)
admin.site.register(BotTexts, BotTextsView)
admin.site.register(Professions)
admin.site.register(BotUsers, BotUsersView)
admin.site.register(Lessons, LessonsView)
