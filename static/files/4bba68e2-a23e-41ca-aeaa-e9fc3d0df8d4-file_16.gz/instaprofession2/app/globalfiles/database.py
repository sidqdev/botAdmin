import asyncpg
import asyncio
import datetime


class Database(object):

    def __new__(cls):
        if not hasattr(cls, '__instance'):
            cls.__instance = super(Database, cls).__new__(cls)
        return cls.__instance

    def __init__(self):
        self.__pool = None

    async def get_pool(self):
        if self.__pool:
            return self.__pool
        return await self.__set_pool()

    async def __set_pool(self):
        self.__pool = await asyncpg.create_pool(
            min_size=1,
            max_size=2,
            host='localhost',
            port=5432,
            database='instaprofession2',
            user='instaprofession2',
            password='instaprofession2'
        )
        return self.__pool

    async def close(self):
        if self.__pool:
            await self.__pool.close()
        self.__pool = None


def connection(func):
    async def wrap(*args, **kwargs):
        pool = await Database().get_pool()
        async with pool.acquire() as conn:
            res = await func(*args, **kwargs, conn=conn)
            await conn.close()
            return res

    return wrap


@connection
async def get_level_ids(conn):
    q = '''SELECT level_id 
           FROM admin_panel_proftest'''

    return await conn.fetch(q)


@connection
async def get_level(level_id, conn):
    q = '''SELECT text, count_of_answers, type
           FROM admin_panel_proftest
           WHERE level_id = $1'''

    return await conn.fetchrow(q, level_id)


@connection
async def get_result(level_id, answer, conn):
    q = '''SELECT admin_panel_professions.id AS profession, admin_panel_answersonproftest.points
           FROM admin_panel_answersonproftest
           INNER JOIN admin_panel_professions 
                ON admin_panel_professions.id = admin_panel_answersonproftest.profession_id
           INNER JOIN admin_panel_proftest
                ON admin_panel_proftest.level_id = admin_panel_answersonproftest.test_id
           WHERE 
                admin_panel_proftest.level_id = $1 AND
                admin_panel_answersonproftest.answer_id = ANY($2)
           '''

    return await conn.fetch(q, level_id, answer)


@connection
async def add_user(uid, name, conn):
    q = '''INSERT INTO admin_panel_botusers(id, name, insert_time)
           VALUES($1, $2, $3)
           ON CONFLICT(id) DO UPDATE SET
           name = EXCLUDED.name'''

    await conn.fetch(q, uid, name, datetime.datetime.now())


@connection
async def get_text(text_id, conn):
    q = '''SELECT text_id, text, image
           FROM admin_panel_bottexts 
           WHERE text_id LIKE ($1 || '%') '''

    return await conn.fetch(q, text_id)


@connection
async def get_professions(conn):
    q = '''SELECT id, text, image
           FROM admin_panel_professions'''

    return await conn.fetch(q)


@connection
async def get_users(conn):
    q = '''SELECT id
           FROM admin_panel_botusers'''

    return await conn.fetch(q)


@connection
async def get_main_menu(prof, conn):
    q = '''SELECT admin_panel_lessons.button_name AS text, admin_panel_lessons.link AS link, 'button' AS type, date AS date
           FROM admin_panel_lessons
           INNER JOIN admin_panel_professions ON admin_panel_professions.id = admin_panel_lessons.profession_id
           WHERE admin_panel_professions.id = $1
           UNION
           SELECT text AS text, image AS link, 'label' AS type, CURRENT_DATE AS date
           FROM admin_panel_bottexts
           WHERE text_id = 'main_menu' 
           ORDER BY date'''

    return await conn.fetch(q, prof)


@connection
async def get_lesson(prof, conn):
    q = '''SELECT admin_panel_lessons.text, admin_panel_lessons.image, admin_panel_lessons.link
           FROM admin_panel_lessons
           INNER JOIN admin_panel_professions ON admin_panel_lessons.profession_id = admin_panel_professions.id
           WHERE admin_panel_lessons.date = CURRENT_DATE AND
                 admin_panel_professions.id = $1'''

    return await conn.fetchrow(q, prof)


@connection
async def get_lesson_debug(prof, day, conn):
    q = '''SELECT admin_panel_lessons.text, admin_panel_lessons.image, admin_panel_lessons.link
           FROM admin_panel_lessons
           INNER JOIN admin_panel_professions ON admin_panel_lessons.profession_id = admin_panel_professions.id
           WHERE admin_panel_lessons.date = $2 AND
                 admin_panel_professions.id = $1'''

    return await conn.fetchrow(q, prof, (datetime.datetime.now() + datetime.timedelta(days=day)).date())


@connection
async def create_tests(i, conn):
    q = '''INSERT INTO admin_panel_proftest(level_id, text, count_of_answers)
           VALUES($1, '.', 1)'''
    await conn.fetch(q, i)
if __name__ == '__main__':

    loop = asyncio.get_event_loop()
    async def task():
        for i in range(3, 19):
            await create_tests(f'level_{i}')
    loop.create_task(task())
    loop.run_forever()
