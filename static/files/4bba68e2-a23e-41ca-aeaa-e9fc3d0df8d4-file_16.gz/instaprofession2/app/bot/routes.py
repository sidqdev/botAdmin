from .loader import dp
from . import handler
from . import states
from aiogram.types import ContentTypes

dp.register_message_handler(handler.reset, commands='reset', state='*')
dp.register_message_handler(handler.start, commands='start', state=None)
dp.register_message_handler(handler.get_menu, commands='menu', state=states.Test.menu)
dp.register_message_handler(handler.set_job, commands='set_job', state='*')
dp.register_message_handler(handler.update_day_handler, commands='set_day', state='*')
dp.register_message_handler(handler.stat, commands='stat', state='*')


dp.register_message_handler(handler.send, commands='send', state='*')
dp.register_message_handler(handler.send, content_types=ContentTypes.ANY, state=states.Spam.get_text)
dp.register_callback_query_handler(handler.send, state=states.Spam.approve)

dp.register_callback_query_handler(handler.close, lambda e: e.data == 'close', state='*')
dp.register_callback_query_handler(handler.test_handler, state=states.Test.test)


