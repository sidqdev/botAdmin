from aiogram.types import Message, CallbackQuery
from aiogram.dispatcher.storage import FSMContext
from app.globalfiles import database
from app.bot import states
from app.bot.loader import bot, scheduler, dp
from app.bot.utils.menu_builder import send_message, get_main_menu, send_time_out_menu, add_push
from app.bot.utils.buttons import InlineKeyboard
import asyncio
from typing import Union
from .scheduler import update_day, spam_form


async def stat(message: Message):
    users = await database.get_users()
    count_ = len(users)
    anket_count = 0
    professions = dict()
    for user in users:
        prof = (await dp.current_state(user=user.get('id'), chat=user.get('id')).get_data()).get('profession')
        if prof:
            anket_count += 1
            professions[prof] = professions.get(prof, 0) + 1

    await message.answer(f'''Всего пользователей: {count_}
Прошли анкету: {anket_count}
Smm: {professions.get('S')}
Сторис: {professions.get('C')}
Сценарист: {professions.get('Y')}
Фотограф: {professions.get('F')}
Копирайтер: {professions.get('K')}
Контент-мейкер: {professions.get('M')}''')


async def update_day_handler(message: Message):
    if not message.text.isdigit():
        await spam_form(debug=True)
        return

    day = int(message.text.split(' ')[-1])
    await update_day(debug=True, day=day)


async def set_job(message: Message, state: FSMContext):
    prof = message.text.split(' ')[-1]
    await state.update_data({'profession': prof})


async def get_menu(message: Message, state: FSMContext):
    await get_main_menu(message.from_user.id, state)


async def close(callback: CallbackQuery):
    text = (await database.get_text('close_lesson'))[0]
    await callback.answer(text.get('text'), show_alert=True)


async def reset(message: Message, state: FSMContext):
    await state.reset_state()
    await message.answer('OK')


async def start(message: Message, state: FSMContext):
    await database.add_user(message.from_user.id, message.from_user.first_name)
    await states.Test.test.set()
    await state.update_data({'level': 1})
    await send_message(message, 'start_1text')
    await asyncio.sleep(6)
    await send_message(message, 'start_2text')
    await asyncio.sleep(10)
    await send_message(message, 'start_3text')
    await asyncio.sleep(22)
    await send_message(message, 'start_text')


async def test_handler(callback: CallbackQuery, state: FSMContext):

    beautiful_ints = ['0️⃣', '1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣' '🔟']
    if callback.data.isdigit() or callback.data == 'next':
        async with state.proxy() as data:
            menu = await database.get_level(f"level_{data['level']}")
            if menu.get('type') == 'mono' or callback.data == 'next':
                if callback.data == 'next':
                    ans = data.get('temp_ans', [])
                else:
                    ans = [int(callback.data)]

                if not ans:
                    await callback.answer('Выберите как минимум один вариант ответа', show_alert=True)
                    return

                res = await database.get_result(f"level_{data.get('level', 0)}", ans)
                print(res)
                for i in res:
                    data[i.get('profession')] = data.get(i.get('profession'), 0) + i.get('points')

                data['level'] = data.get('level', 0) + 1
                data['temp_ans'] = list()
            else:
                ans = int(callback.data)
                if ans not in data.get('temp_ans', []):
                    data['temp_ans'] = data.get('temp_ans', []) + [ans]
                else:
                    data['temp_ans'].remove(ans)

    async with state.proxy() as data:

        for msg in data.get('message_to_remove', []):
            try:
                await bot.delete_message(callback.from_user.id, msg)
            except:
                pass
        for jid in data.get('jobs', []):
            print(jid)
            try:
                scheduler.remove_job(job_id=jid)
            except Exception as e:
                print(e)

        data['jobs'] = list()
        data['message_to_remove'] = list()

        menu = await database.get_level(f"level_{data['level']}")
        if menu:
            j1 = await add_push(callback.from_user.id, 'push1', 10 * 60)
            j2 = await add_push(callback.from_user.id, 'push2', 30 * 60)
            data['jobs'] = [j1, j2]
            text = menu.get('text')
            button = list()
            for i in range(1, menu.get('count_of_answers') + 1):
                button.append({'data': i, 'text': beautiful_ints[i] + ('✅' if i in data.get('temp_ans', []) else '')})

            if menu.get('type') == 'multi':
                button.append({'data': 'next', 'text': 'Дальше 👉'})

            await callback.message.edit_text(text, reply_markup=InlineKeyboard(*button))
        else:
            await states.Test.menu.set()
            row_professions = await database.get_professions()
            professions = list()
            for i in row_professions:
                i = dict(i)
                i['points'] = data.get(i.get('id'), 0)
                professions.append(i)

            result = max(professions, key=lambda x: x.get('points'))
            data['profession'] = result.get('id')
            await callback.message.delete()
            await callback.message.answer_photo(photo=result.get('image'), caption=result.get('text'))
            await asyncio.sleep(6)
            await send_message(callback, 'endtest1')
            await asyncio.sleep(12)
            await send_message(callback, 'endtest2')
            send_time_out_menu(callback.from_user.id, 'get_code', 40 * 60)
            send_time_out_menu(callback.from_user.id, 'watch_inter', 100 * 60)


async def send(message: Union[Message, CallbackQuery], state: FSMContext):
    if type(message) is Message:
        if message.text == '/send':
            await message.answer('Пожалуйста отправьте текст рассылки и, если нужно, прикрепите картинку/видео')
            await states.Spam.get_text.set()
        else:
            mid = message.message_id
            cid = message.chat.id
            await state.update_data({'spam_mid': mid, 'spam_cid': cid})

            await message.answer('Так сообщение отправится пользователям ☝️',
                                 reply_markup=InlineKeyboard({'text': 'Отправить', 'data': 'approve'},
                                                             {'text': 'Отменить действие', 'data': 'disapprove'}))
            await states.Spam.approve.set()

    elif type(message) is CallbackQuery:
        if message.data == 'approve':
            data = await state.get_data()
            mid = data.get('spam_mid')
            cid = data.get('spam_cid')
            await message.message.edit_text('Начало рассылки', reply_markup=None)
            loop = asyncio.get_event_loop()
            loop.create_task(start_spam(mid, cid))
            await message.message.answer('Рассылка окончена')
        else:
            await state.update_data({'spam_mid': 0, 'spam_cid': 0})
            await message.message.edit_text('Не отправлено, действие отменено', reply_markup=None)


async def start_spam(mid, cid):
    users = await database.get_users()
    for user in users:
        try:
            await bot.copy_message(user.get('id'), cid, mid)
        except:
            pass

        await asyncio.sleep(0.04)




