from .loader import scheduler
from app.globalfiles import database
from datetime import datetime
from .utils import buttons
from .loader import bot, dp
import asyncio


async def update_day(debug=False, day=None):
    users = await database.get_users()

    if debug:
        users = [{'id': 506563771}, {'id': 366276154}]

    for user in users:
        try:
            prof = (await dp.current_state(user=user.get('id'), chat=user.get('id')).get_data()).get('profession')
            lesson = await database.get_lesson(prof)
            if debug:
                lesson = await database.get_lesson_debug(prof, day)
            reply_markup = buttons.InlineKeyboard({'text': 'Посмотреть урок 🤩', 'data': lesson.get('link')})
            await bot.send_photo(user.get('id'), photo=lesson.get('image'),
                                 caption=lesson.get('text'), reply_markup=reply_markup)
        except Exception as e:
            print(e)
        finally:
            await asyncio.sleep(0.04)


async def spam_form(debug=False):
    menu1 = await database.get_text('spam_form')
    menu1 = menu1[0]
    reply_markup1 = buttons.InlineKeyboard(
        {'text': 'Заполнить форму 📝', 'data': 'https://forms.gle/3PbS6movcLm7Qrdx9'})

    menu2 = await database.get_text('spam_0001')
    menu2 = menu2[0]
    reply_markup2 = buttons.InlineKeyboard({'text': 'Посмотреть урок 🤩', 'data': 'http://insta-academy.club/last-step'})

    users = await database.get_users()
    if debug:
        users = [{'id': 506563771}, {'id': 366276154}]
    for user in users:
        try:
            await bot.send_message(chat_id=user.get('id'), text=menu2.get('text'), reply_markup=reply_markup2)
            await bot.send_message(chat_id=user.get('id'), text=menu1.get('text'), disable_web_page_preview=True,
                                   reply_markup=reply_markup1)
        except:
            pass
        finally:
            await asyncio.sleep(0.08)


async def spam(text):
    users = await database.get_users()

    for user in users:
        try:
            await bot.send_message(chat_id=user.get('id'), text=text, disable_web_page_preview=True)
        except:
            pass
        finally:
            await asyncio.sleep(0.04)


# texts_21_09 = ['СМОТРИ ИНТЕРВЬЮ ПОД ЭТИМ ВИДЕО - НАХОДИ 3 КОДОВОЕ СЛОВО  🚀',
#          'ЗАПОМНИ ЭТУ ДАТУ - 23 ,СЕНТЯБРЯ 19:00 Грандиозный онлайн эфир, розыгрыш 10 000 грн и 2 мест в академии прямо в онлайне 🔥',
#          '''КАК? ТЫ ЕЩЕ НЕ УСПЕЛ ПОСМОТРЕТЬ ВИДЕО И СТАТЬ БЛИЖЕ К РОЗЫГРАШУ 10 000 ГРН  🙃
# ОСТАЛСЯ ОДИН ДЕНЬ ТЫ НЕ МОЖЕШЬ ЕГО ПРОПУСТЬ 🔥''']

# texts_22_09 = ['''Уверены, что вы уже проложили маленькую ступень к огромной дороге успеха 🚀
# НЕ ПРОПУСТИЛ 4 КОДОВОЕ СЛОВО В ЭТОМ ВИДЕО? 🙃''',
#                '''Не просто смотри уроки, а собери кодовую фразу и выиграй денежный приз 10 000 грн и 2 места обучения на курсе 🚀
#
# Помни, что кодовая фраза состоит из 5 слов''',
#                '''УЖЕ СЕГОДНЯ  - 23 СЕНТЯБРЯ, 19:00 Грандиозный онлайн эфир, розыгрыш 10 000 грн и 2 мест в академии прямо в онлайне 🔥''']
#
# texts_23_09 = ['''Ты огромный молодец, если ты не сдался и мы с тобой сейчас встретились 👩‍🎓
# Скажи, было интересно? Много нового узнал?''']

# scheduler.add_job(spam, 'date', ['тест'], run_date=datetime(2021, 9, 21, 14))
# scheduler.add_job(spam, 'date', [texts_21_09[1]], run_date=datetime(2021, 9, 21, 13, 10))
# scheduler.add_job(spam, 'date', [texts_21_09[2]], run_date=datetime(2021, 9, 21, 14, 10))

# scheduler.add_job(spam, 'date', [texts_22_09[0]], run_date=datetime(2021, 9, 22, 12, 30))
#
# scheduler.add_job(spam, 'date', [texts_22_09[1]], run_date=datetime(2021, 9, 22, 13))

# scheduler.add_job(spam_form, 'date', run_date=datetime(2021, 9, 22, 15, 0, 0))
#
# scheduler.add_job(spam, 'date', ['''Ты огромный молодец, если ты не сдался и мы с тобой сейчас встретились 👩‍🎓
# Скажи, было интересно? Много нового узнал?'''], run_date=datetime(2021, 9, 22, 16, 0, 0))

# scheduler.add_job(spam, 'date', ['''УЖЕ ЗАВТРА  - 23 СЕНТЯБРЯ, 19:00 Грандиозный онлайн эфир, розыгрыш 10 000 грн и 2 мест в академии прямо в онлайне 🔥'''],
#                   run_date=datetime(2021, 9, 22, 18, 0, 0))

#
# scheduler.add_job(spam, 'date', ['''НЕ ЗАБЫЛ?
#
# УЖЕ СЕГОДНЯ  - 23 СЕНТЯБРЯ буду ждать именно тебя в 19:00 на онлайн эфире, где розыграю 10 000 грн и 2 мест в академии прямо в онлайне 👩‍🎓 '''],
#                   run_date=datetime(2021, 9, 23, 11, 0, 0))

# scheduler.add_job(spam, 'date', ['''🚀 В 19:00 СЕГОДНЯ Не пропусти наш грандиозный онлайн эфир где ты:
# - узнаешь как освоить новую креативную insta профессию
# - познакомим тебя с нашими выпускниками, которые уже изменили свою жизнь
# - расскажем где найти первый проект и заработать на нем денег
#
# Ну и конечно разыграем денежный приз и два места в академии  🔥'''],
#                   run_date=datetime(2021, 9, 23, 13, 0, 0))
#
# scheduler.add_job(spam, 'date', ['''Друзьяяяя, полная боевая готовность как говорят 😂
# Хочу видеть именно тебя, для меня это действительно важно!
#
# ❗️Планируйте свой вечер, чтобы в 19:00 все уже были у экранов и телефонов.
# А еще не забывайте, что сегодня разыграю 10 000 в прямом эфире 💸
#
# Кто не успел, быстро регистрируйтесь 👇
# https://start.bizon365.ru/room/62231/ellert
# https://start.bizon365.ru/room/62231/ellert '''],
#                   run_date=datetime(2021, 9, 23, 16, 0, 0))
#
# scheduler.add_job(spam, 'date', ['''Мы ужеееее начинаем. Здесь будет просто огонь 🔥
# Ты не можешь такое пропустить. Впервые начинаю рассказывать историю своей трансформации и как у меня все получилось 💸
#
# Интересно? Подключайся 👇
# https://start.bizon365.ru/room/62231/ellert '''],
#                   run_date=datetime(2021, 9, 23, 18, 50, 0))
#
# scheduler.add_job(spam, 'date', ['''❗️Так, не хватает именно тебя.
# Ты хочешь изменить свою жизнь? Я как раз рассказываю как это сделать.
# А еще разыграю 10 000 гривен и бесплатное место 💸
#
# ❗️Быстро подключайся:
# https://start.bizon365.ru/room/62231/ellert '''],
#                   run_date=datetime(2021, 9, 23, 19, 5, 0))
#
# scheduler.add_job(spam, 'date', ['''Друзьяяяя,  здесь такое грандиозное действо. Я даже не могу описать словами 😭
#
# Вы просто должны это увидеть.
#
# НЕ сомневайся, давай быстро к нам 🚀
# https://start.bizon365.ru/room/62231/ellert '''],
#                   run_date=datetime(2021, 9, 23, 20, 5, 0))

# scheduler.add_job(spam, 'date', [''''''],
#                   run_date=datetime(2021, 9, 23, 18, 0, 0))

# scheduler.add_job(spam, 'date', [texts_23_09[0]], run_date=datetime(2021, 9, 23, 13))


scheduler.add_job(update_day, 'cron', hour=11, minute=55, second=0)
scheduler.start()
