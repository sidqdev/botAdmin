from app.globalfiles.config import bot_config, mongo_config
from aiogram import Bot, Dispatcher
from aiogram.contrib.fsm_storage.mongo import MongoStorage
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from apscheduler.schedulers.asyncio import AsyncIOScheduler


storage = MongoStorage(host=mongo_config.get('host'), port=mongo_config.get('port'),
                       db_name=mongo_config.get('db_name'))

bot = Bot(token=bot_config.get('token'), parse_mode='html')
dp = Dispatcher(bot, storage=storage)

scheduler = AsyncIOScheduler()

dp.middleware.setup(LoggingMiddleware())

